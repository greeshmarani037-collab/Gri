STUDENT MANAGEMENT SYSTEM
Java + JDBC + MySQL + Maven

FEATURES
1. Add student
2. View all students
3. Search student
4. Update student
5. Delete student
6. Exit

REQUIREMENTS
- JDK 17 or later
- MySQL 8+
- Maven 3.8+
- IntelliJ IDEA / Eclipse / VS Code

SETUP
1. Open MySQL.
2. Run database/student_management.sql.
3. Open src/main/java/com/studentmanagement/DBConnection.java.
4. Change DB_USER and DB_PASSWORD to your MySQL username/password.
5. Open terminal in this project folder.
6. Run: mvn clean compile
7. Run: mvn exec:java

JDBC FLOW
Java Application
      ↓
JDBC Driver
      ↓
Connection
      ↓
PreparedStatement
      ↓
MySQL Database

This is a simple college project designed to demonstrate JDBC CRUD operations.
