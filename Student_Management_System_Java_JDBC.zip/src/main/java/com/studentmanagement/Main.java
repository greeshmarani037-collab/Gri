package com.studentmanagement;

import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final StudentDAO dao = new StudentDAO();

    public static void main(String[] args) {

        while (true) {
            printMenu();

            try {
                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1 -> addStudent();
                    case 2 -> viewStudents();
                    case 3 -> searchStudents();
                    case 4 -> updateStudent();
                    case 5 -> deleteStudent();
                    case 6 -> {
                        System.out.println("Thank you for using Student Management System!");
                        return;
                    }
                    default -> System.out.println("Please choose 1 to 6.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n========================================");
        System.out.println("       STUDENT MANAGEMENT SYSTEM");
        System.out.println("========================================");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Search Student");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("6. Exit");
        System.out.print("Enter choice: ");
    }

    private static void addStudent() {

        System.out.println("\n--- Add Student ---");

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        System.out.print("Course: ");
        String course = sc.nextLine();

        System.out.print("Year: ");
        int year = Integer.parseInt(sc.nextLine());

        System.out.print("Marks: ");
        double marks = Double.parseDouble(sc.nextLine());

        Student student =
                new Student(name, email, phone, course, year, marks);

        if (dao.addStudent(student)) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Unable to add student.");
        }
    }

    private static void viewStudents() {

        System.out.println("\n--- All Students ---");

        List<Student> students = dao.getAllStudents();

        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }

        printStudents(students);
    }

    private static void searchStudents() {

        System.out.print("\nEnter name, email or course to search: ");
        String keyword = sc.nextLine();

        List<Student> students = dao.searchStudents(keyword);

        if (students.isEmpty()) {
            System.out.println("No matching students found.");
            return;
        }

        printStudents(students);
    }

    private static void updateStudent() {

        System.out.print("\nEnter student ID: ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("New name: ");
        String name = sc.nextLine();

        System.out.print("New email: ");
        String email = sc.nextLine();

        System.out.print("New phone: ");
        String phone = sc.nextLine();

        System.out.print("New course: ");
        String course = sc.nextLine();

        System.out.print("New year: ");
        int year = Integer.parseInt(sc.nextLine());

        System.out.print("New marks: ");
        double marks = Double.parseDouble(sc.nextLine());

        Student student =
                new Student(id, name, email, phone, course, year, marks);

        if (dao.updateStudent(student)) {
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Student ID not found.");
        }
    }

    private static void deleteStudent() {

        System.out.print("\nEnter student ID: ");
        int id = Integer.parseInt(sc.nextLine());

        if (dao.deleteStudent(id)) {
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student ID not found.");
        }
    }

    private static void printStudents(List<Student> students) {

        System.out.println("ID   Name                 Email                     Phone         Course   Year  Marks");
        System.out.println("------------------------------------------------------------------------------------------");

        for (Student student : students) {
            System.out.println(student);
        }
    }
}
