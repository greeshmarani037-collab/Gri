package com.studentmanagement;

public class Student {

    private int id;
    private String name;
    private String email;
    private String phone;
    private String course;
    private int year;
    private double marks;

    public Student() {
    }

    public Student(String name, String email, String phone,
                   String course, int year, double marks) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.course = course;
        this.year = year;
        this.marks = marks;
    }

    public Student(int id, String name, String email, String phone,
                   String course, int year, double marks) {
        this(name, email, phone, course, year, marks);
        this.id = id;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getCourse() { return course; }
    public int getYear() { return year; }
    public double getMarks() { return marks; }

    @Override
    public String toString() {
        return String.format(
                "%-4d %-20s %-25s %-13s %-8s %-5d %.2f",
                id, name, email, phone, course, year, marks
        );
    }
}
